import {useState} from "react"
import axios from "axios"
import { BASE_URL } from "./utils/constants";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addUser } from "./utils/userSlice";
const Login =()=>{
    const {emailId,setEmailId} = useState("");
    const {password,setPassword}=useState("");
      const {firstName,setFirstName} = useState("");
    const {lastName,setLastName}=useState("");
    const {isLoginForm,setIsLoginForm}=useState(true);
    const [error,setError]=useState("");
    const dispatch=useDispatch();
    const navigate =useNavigate();
    
    const handleSignUp=async()=>{
      try{
        const res =await axios.post(BASE_URL + "/signUp",
          {firstName,lastName,emailId,password},
          {withCredentials:true},);
          dispatch(addUser(res.data.data));
          return navigate("/profile");
      }catch(err){
        console.log(err);
      }
    }

    const handleLogin=async ()=>{
      try{
        const res=  await axios.post(BASE_URL + "/login",{
            emailId,password,
        },
    {withCredentials:true},
);
dispatch(addUser(res.data.data));
return navigate("/");
      }
      catch(err){
        setError(err?.response?.data || "something went wrong");
      //  console.error(err?.response?.message || "something went wrong"); 
      }
    };
     return (
<div className="flex justify-center my-10">  
    <div className="card bg-base-300 w-96 shadow-sm ">
  <div className="card-body">
    <h1 className="card-title mx-35" >{isLoginForm?"Login":"SignUp"}</h1>
   <div>    
    {/* First Name */}
   {!isLoginForm &&  <fieldset className="fieldset">
     
  <legend className="fieldset-legend"    >First Name</legend>
  <input type="text" value={firstName} onChange={(e)=>setFirstName(e.target.value)} className="input" placeholder="abcxyz@gmail.com" />
  
</fieldset> }
 {/* Last Name*/}
 {!isLoginForm && <fieldset className="fieldset">
  <legend className="fieldset-legend">Last Name</legend>
  <input type="text" value={lastName} onChange={(e)=>setLastName(e.target.value)} className="input" placeholder="Enter your Password" />
</fieldset> }
 {/* Email Id */}
    <fieldset className="fieldset">
     
  <legend className="fieldset-legend"     >Email Id</legend>
  <input type="text" value={emailId} onChange={(e)=>setEmailId(e.target.value)} className="input" placeholder="abcxyz@gmail.com" />
  
</fieldset>
 {/* Password*/}
 <fieldset className="fieldset">
  <legend className="fieldset-legend">Password</legend>
  <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} className="input" placeholder="Enter your Password" />
</fieldset>
   </div>
   <p className="text-red-500">{error}</p>
    <div className="card-actions justify-end">
      <button className="btn btn-primary" onClick={isLoginForm?handleLogin:handleSignUp}>
        {isLoginForm? " Login" : "SignUp"}
        </button>
    </div>
    <p  className =" m-auto cursor-pointer py-2 " onClick={()=>setIsLoginForm(!isLoginForm)}>
      {isLoginForm? "New User : SignUp here" : "Already have Account : Login here"}
    </p>
  </div>
</div>   
</div>
    )
};

export default Login;

