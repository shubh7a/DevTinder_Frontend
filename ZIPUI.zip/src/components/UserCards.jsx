import axios from "axios";
import { BASE_URL } from "../utils/constants";
import { useDispatch } from "react-redux";
import { removeFeed } from "../utils/feedSlice";
const UserCards=({user})=>{
  const dispatch=useDispatch();
    const {_id,firstName, lastName,age,gender,about}=user;
    const handleSendRequest=async(status,_id)=>{
      try{
        await axios.post(BASE_URL + "/request/send/"+status +"/"+_id 
          ,{},{withCredentials:true,});
          dispatch(removeFeed(_id));
      }catch(err){
        console.log(err.message);
      }
    }
    return (
        <>  
        <div className="card bg-base-300 w-96 shadow-sm">
  <figure>
    <img
    src={ "https://i.pravatar.cc/400"} 
    //  src="https://img.daisyui.com/images/stock/photo-1606107557195-0e29a4b5b4aa.webp"
      alt="Shoes" />
  </figure>
  <div className="card-body">
    <h2 className="card-title">{firstName + " " + lastName}</h2>
   {age && gender && <p>{age + "," + gender}</p>}
    <p>{about}</p>
    <div className="card-actions justify-end">
      <button className="btn btn-secondary" onclick ={()=>handleSendRequest("ignored",_id)} >Ignore</button>
      <button className="btn btn-primary" onClick={()=>handleSendRequest("Interested",_id)} >Interested</button>
    </div>
  </div>
</div>
        </>
    )
}

export default UserCards;