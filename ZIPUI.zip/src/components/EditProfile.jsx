 import { useState } from "react";
 import UserCards from "./UserCards";
 import axios from "axios";
 import { BASE_URL } from "../utils/constants";
 import { useDispatch } from "react-redux";
 const EditProfile=({user})=>{
    
        const {firstName,setFirstName} = useState(user.firstName);
        const {lastName,setLastName}=useState(user.lastName);
        const {age,setAge} = useState(user.age);
        const {photoUrl,setPhotoUrl} = useState(user.photoUrl);
        const {gender,setGender}=useState(user.gender);
        const {about ,setAbout}=useState(user.about);
        const [error,setError]=useState("");
        const dispatch=useDispatch();
        const [showToast ,setShowToast] = useState(false);
        const saveProfile=async()=>{
            //clear error before saving profile
            setError("");
            try{
                const res =await axios.patch(BASE_URL + "/profile/edit",{firstName, lastName, age, photoUrl, gender, about},{withCredentials:true});
                dispatch(addUser(res?.data?.data));
                setShowToast(true);
                setTimeout(()=>{
                  setShowToast(false);
                },3000)
            }catch(err){
                setError(err?.response?.data || "something went wrong");
            }
        }
    return (  
      <div>
{showToast} &&
 (<div className="flex justify-center my-10">   
<div className="flex justify-center mx-10">  
    <div className="card bg-base-300 w-96 shadow-sm ">
  <div className="card-body">
    <h1 className="card-title justify-center mx-35">Edit Profile</h1>
   <div>    
 {/*First Name*/}
    <fieldset className="fieldset">
     
  <legend className="fieldset-legend" >First Name</legend>
  <input type="text" value={firstName} onChange={(e)=>setFirstName(e.target.value)} className="input" placeholder="abcxyz@gmail.com" />
  
</fieldset>
 {/* Last Name*/}
 <fieldset className="fieldset">
  <legend className="fieldset-legend">Last Name</legend>
  <input type="text" value={lastName} onChange={(e)=>setLastName(e.target.value)} className="input" placeholder="Enter your Last Name" />
</fieldset>
{/*Age*/}
    <fieldset className="fieldset">
     
  <legend className="fieldset-legend" >Age</legend>
  <input type="text" value={age} onChange={(e)=>setAge(e.target.value)} className="input" placeholder="abcxyz@gmail.com" />
  
</fieldset>
 {/* Gender*/}
 <fieldset className="fieldset">
  <legend className="fieldset-legend">Gender</legend>
  <input type="text" value={gender} onChange={(e)=>setGender(e.target.value)} className="input" placeholder="Enter your Last Name" />
</fieldset>
{/* About*/}
 <fieldset className="fieldset">
  <legend className="fieldset-legend">About</legend>
  <input type="text" value={about} onChange={(e)=>setAbout(e.target.value)} className="input" placeholder="Enter your Last Name" />
</fieldset>
{/* photo*/}
 <fieldset className="fieldset">
  <legend className="fieldset-legend">Photo</legend>
  <input type="text" value={photoUrl} onChange={(e)=>setPhotoUrl(e.target.value)} className="input" placeholder="Enter your Last Name" />
</fieldset>
   </div>
   <p className="text-red-500">{error}</p>
    <div className="card-actions justify-end">
      <button className="btn btn-primary" onClick={saveProfile}>
        Save Profile
        </button>
    </div>
  </div>
</div>   
</div>
    <UserCards user={{ firstName, lastName, age, photoUrl, gender, about }} />
</div>

<div className="toast toast-top toast-center">
  <div className="alert alert-success">
    <span>Profile Updated Successfully.</span>
  </div>
</div>)

    </div>
    )
 }
 export default EditProfile;