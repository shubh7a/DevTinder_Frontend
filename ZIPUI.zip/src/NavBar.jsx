import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { BASE_URL } from "./utils/constants";
import { removeUser } from "./utils/userSlice";

const NavBar=() =>{
  const user =useSelector((store)=>store.user);
  const dispatch = useDispatch();
  const navigate=useNavigate();
  const handleLogout= async ()=>{
try{
await axios.post(BASE_URL + "/logout",{},{withCredentials:true});
dispatch(removeUser());
 return navigate("/login");
}catch(err){
 //  setError(err.message);
  console.error(err?.response?.message || "Something went wrong");
}
  };
    return (
        <>  
        <div className="navbar bg-base-300 shadow-sm">
  <div className="flex-1">
    <Link to ="/" className="btn btn-ghost text-xl">DevTinder</Link>
  </div>
  {user && (
    <div className="flex-none gap-2">
      <div className="form-control">Welcome, {user.firstName}</div>
      {/* <input type="text" placeholder="Search" className="input input-bordered w-24 md:w-auto" /> */}
      <div className="dropdown dropdown-end mx-5 flex "> 
        <div tabIndex={0} role="button" className="btn btn-ghost btn-circle avatar">
          <div className="w-10 rounded-full">
          <img
            alt="user Pic"
             src={user.photoUrl || "https://i.pravatar.cc/40"}/>
        </div>
      </div>
      <ul
        tabIndex="-1"
        className="menu menu-sm dropdown-content bg-base-100 rounded-box z-1 mt-3 w-52 p-2 shadow">
        <li>
          <Link to="/Profile" className="justify-between">
            Profile
            <span className="badge">New</span>
          </Link>
        </li>
        <li><Link to ="/connections">Connections</Link></li>
        <li><Link to ="/requests"> Requests</Link></li>
        <li><a onClick={handleLogout}>Logout</a></li>
      </ul>
    </div>
  </div>
  )}
</div>
  
        </>
    )
}

export default NavBar;
