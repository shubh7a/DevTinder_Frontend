import axios from "axios";
import { BASE_URL } from "./utils/constants";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addConnections } from "./utils/connectionsSlice";

const Connections=()=>{
    const dispatch = useDispatch();
    const connections=useSelector((store)=>store.connections);
    const fetchConnections = async()=>{
        try{
            const res= await axios.get(BASE_URL+"/connections",{withCredentials:true,});
            dispatch(addConnections(res.data.data));
       
        }catch(err){
            console.error(err);
        }
    }
    useEffect(()=>{
        fetchConnections();
    },[]); 
 
    if(!connections) return;

    if(connections.length===0)return <h1 className="flex justify-center my-18 ">No Connections Found</h1>;
    return (
        <div className=" flex  justify-center text-center my-18"> 
        <h1 className="text-bold text-2xl">Connections</h1>  

      {connections.map((connection)=>{
    const {firstName,lastName,age,photoUrl,gender,about}=connection;
               return ( <div className="m-4 p-4 border">
                             <div> 
                          <img alt="pic" className="w-29 h-29 " src={photoUrl}/> 
                           </div>

                    <div className="text-left mx-4"> 
                        <h2 className="font-bold text-xl">{firstName  + "" + lastName}</h2>
             
               {age && gender && <p>{age + " " + gender}</p>}
                  <p>{about}</p>
                    </div>
                    </div>)
            })}
        </div>
    )
}
export default Connections;