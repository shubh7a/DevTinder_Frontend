/* eslint-disable no-unused-vars */
import axios from "axios";
import { BASE_URL } from './utils/constants';
import { useDispatch, useSelector } from "react-redux";
import { addRequests, removeRequest } from "./utils/requestSlice";
import { useEffect } from "react";
const Requests=()=>{
    const requests=useSelector((store)=>store.requests);
    const dispatch=useDispatch();

    const reviewRequest=async (status,_id)=>{
        try{
            const res=await axios.post(BASE_URL + "/request/review/"+ status+"/" + _id,{}
                ,{withCredentials:true,}); 
                dispatch(removeRequest(_id));
        }catch(err){
            console.error(err.message);
        }
    }
    const fetchRequests= async ()=>{
        try{
            
        const res= await axios.get(BASE_URL + "/user/requests/recieved" ,{withCredentials:true,});
        dispatch(addRequests(res.data.data));
    }catch(err){
        console.error(err.message);
        } 
    };
    useEffect(()=>{
        fetchRequests();
    },[]);

    if(!requests) return;

    if(requests.length===0)return <h1 className="flex justify-center my-18 ">No Requests Found</h1>;
    return (
        <div className=" flex  justify-center text-center my-18"> 
        <h1 className="text-bold text-2xl">Requests</h1>  

      {requests.map((request)=>{
    const {_id,firstName,lastName,age,photoUrl,gender,about}=request.fromUserId;
               return ( <div key={_id} className="flex justify-between m-4 p-4 rounded-lg shadow-lg bg-white w-1/2 mx-auto items-center">
                             <div> 
                          <img alt="pic" className="w-29 h-29 " src={photoUrl}/> 
                           </div>

                    <div className="text-left mx-4"> 
                        <h2 className="font-bold text-xl">{firstName  + "" + lastName}</h2>
             
               {age && gender && <p>{age + " " + gender}</p>}
                  <p>{about}</p>
                    </div>
                    <div> <button className="btn btn-primary" onClick={()=>reviewRequest("rejected",request._id)}>Reject</button>
<button className="btn btn-secondary" onClick={()=>reviewRequest("accepted",request._id)}>Accept</button>
</div>
                    </div>)
            })}
        </div>
    )
}
export default Requests;